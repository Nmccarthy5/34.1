/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class StaffManager {

    private static final String URL = "jdbc:sqlite:client.db";

    public static Connection connect() {
        try {
            return DriverManager.getConnection(URL);
        } catch (SQLException e) {
            return null;
        }
    }

    public static void viewStaff(String id) {
        String sql = "SELECT * FROM Staff WHERE id=?";
        try (Connection conn = connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, id);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                System.out.println(rs.getString("lastName") + ", " +
                                   rs.getString("firstName") + ", " +
                                   rs.getString("mi") + ", " +
                                   rs.getString("address") + ", " +
                                   rs.getString("city") + ", " +
                                   rs.getString("state") + ", " +
                                   rs.getString("telephone") + ", " +
                                   rs.getString("email"));
            }
        } catch (Exception e) {
        }
    }

    public static void insertStaff(String id, String lastName, String firstName, String mi,
                                   String address, String city, String state, String telephone, String email) {
        String sql = "INSERT INTO Staff(id, lastName, firstName, mi, address, city, state, telephone, email) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, id);
            pstmt.setString(2, lastName);
            pstmt.setString(3, firstName);
            pstmt.setString(4, mi);
            pstmt.setString(5, address);
            pstmt.setString(6, city);
            pstmt.setString(7, state);
            pstmt.setString(8, telephone);
            pstmt.setString(9, email);

            pstmt.executeUpdate();
        } catch (Exception e) {
        }
    }

    public static void updateStaff(String id, String lastName, String firstName, String mi,
                                   String address, String city, String state, String telephone, String email) {
        String sql = "UPDATE Staff SET lastName=?, firstName=?, mi=?, address=?, city=?, state=?, telephone=?, email=? WHERE id=?";
        try (Connection conn = connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, lastName);
            pstmt.setString(2, firstName);
            pstmt.setString(3, mi);
            pstmt.setString(4, address);
            pstmt.setString(5, city);
            pstmt.setString(6, state);
            pstmt.setString(7, telephone);
            pstmt.setString(8, email);
            pstmt.setString(9, id);

            pstmt.executeUpdate();
        } catch (Exception e) {
        }
    }

    public static void main(String[] args) {
        // Example Usage:
        insertStaff("123456789", "Doe", "John", "M", "123 Elm St", "Springfield", "IL", "1234567890", "john.doe@email.com");
        viewStaff("123456789");
        updateStaff("123456789", "Doe", "John", "M", "456 Maple St", "Springfield", "IL", "0987654321", "john.doe@email.com");
        viewStaff("123456789");
    }
}